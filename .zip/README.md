# HabitTracker-App

In this app, you will be able to add your daily habits, as well as delete them if you already complete them. In addition, I have provided a Chatbox AI so you can ask for help if you need something related with ypur habits!
You are secure as all the information will be stored in firebase database, also your habits are going to be stored with your user information.
We have added a biometrics login so its gonna be eaiser for you to log in and register!